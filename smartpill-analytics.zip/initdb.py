from smartpillbottle import init_db
init_db()